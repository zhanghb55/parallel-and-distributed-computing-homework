#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define SIZE 512

int N = SIZE;


void divide(int*source,int*first,int*second,int*third,int*fourth){
    int left = source[0];
    int right = source[1];
    int top = source[2];
    int bottom = source[3];
    
    first[0] = left;
    first[1] = (left + right) / 2;
    first[2] = top;
    first[3] = (top + bottom) / 2;
    
    second[0] = (left + right + 1) / 2;
    second[1] = right;
    second[2] = top;
    second[3] = (top + bottom) / 2;
    
    third[0] = left;
    third[1] = (left + right) / 2;
    third[2] = (top + bottom + 1) / 2;
    third[3] = bottom;
    
    fourth[0] = (left + right + 1) / 2;
    fourth[1] = right;
    fourth[2] = (top + bottom + 1) / 2;
    fourth[3] = bottom;
}

void multiply(int** A,int **B,int ** C,int*A_flag,int*B_flag){
    
    if(N == 2){
        C[A_flag[2]][B_flag[0]] = A[A_flag[2]][A_flag[0]]*B[B_flag[2]][B_flag[0]]+A[A_flag[2]][A_flag[1]]*B[B_flag[3]][B_flag[0]]+C[A_flag[2]][B_flag[0]];
        C[A_flag[2]][B_flag[1]] = A[A_flag[2]][A_flag[0]]*B[B_flag[2]][B_flag[1]]+A[A_flag[2]][A_flag[1]]*B[B_flag[3]][B_flag[1]]+C[A_flag[2]][B_flag[1]];
        C[A_flag[3]][B_flag[0]] = A[A_flag[3]][A_flag[0]]*B[B_flag[2]][B_flag[0]]+A[A_flag[3]][A_flag[1]]*B[B_flag[3]][B_flag[0]]+C[A_flag[3]][B_flag[0]];
        C[A_flag[3]][B_flag[1]] = A[A_flag[3]][A_flag[0]]*B[B_flag[2]][B_flag[1]]+A[A_flag[3]][A_flag[1]]*B[B_flag[3]][B_flag[1]]+C[A_flag[3]][B_flag[1]];
    }
    else{
        N /= 2;
        int A_first[4],A_second[4],A_third[4],A_fourth[4];
        int B_first[4],B_second[4],B_third[4],B_fourth[4];
        
        divide(A_flag, A_first, A_second, A_third, A_fourth);
        divide(B_flag, B_first, B_second, B_third, B_fourth);
        
        multiply(A,B,C,A_first,B_first);
        multiply(A,B,C,A_second,B_third);
        //
        multiply(A,B,C,A_first,B_second);
        multiply(A,B,C,A_second,B_fourth);
        //
        multiply(A,B,C,A_third,B_first);
        multiply(A,B,C,A_fourth,B_third);
        //
        multiply(A,B,C,A_third,B_second);
        multiply(A,B,C,A_fourth,B_fourth);
    }
}
int main(){
    int m ,p ,n ;
    m = p = n = SIZE;
    int **a,**b,**c;
    a = (int**)malloc(sizeof(int*)*m);
    b = (int**)malloc(sizeof(int*)*p);
    c = (int**)malloc(sizeof(int*)*m);
    int i;
    for(i = 0;i < m;i++){
        a[i] = (int*)malloc(sizeof(int)*p);
        c[i] = (int*)malloc(sizeof(int)*n);
        memset(a[i],0,sizeof(int)*p);
        memset(c[i],0,sizeof(int)*n);
    }
    for(i = 0;i < p;i++){
        b[i] = (int*)malloc(sizeof(int)*n);
        memset(b[i],0,sizeof(int)*n);
    }
    //brute_force(a,b,c,m,n,p);
    int a_shape[4] = {0,SIZE - 1,0,SIZE - 1};
    int b_shape[4] = {0,SIZE - 1,0,SIZE - 1};
    multiply(a,b,c,a_shape,b_shape);
}
