#include <stdio.h>
#include <string.h>
#include<stdlib.h>

#define SIZE 512

void brute_force(int**a,int**b,int**c,int m,int n,int p){
    int i,j,k;
    //矩阵乘法
    for (i = 0; i <= m - 1; i++) {
        for (j = 0; j <= n - 1; j++) {
            for (k = 0; k <= p - 1; k++) {
                c[i][j] += a[i][k] * b[k][j];
            }
        }
    }
}


int main(){
    int m = 2,p = 4,n = 3;
    int **a,**b,**c;
    a = (int**)malloc(sizeof(int*)*m);
    b = (int**)malloc(sizeof(int*)*p);
    c = (int**)malloc(sizeof(int*)*m);
    int i,j;
    for(i = 0;i < m;i++){
        a[i] = (int*)malloc(sizeof(int)*p);
        c[i] = (int*)malloc(sizeof(int)*n);
        memset(a[i],0,sizeof(int)*p);
        memset(c[i],0,sizeof(int)*n);
    }
    for(i = 0;i < p;i++){
        b[i] = (int*)malloc(sizeof(int)*n);
        memset(b[i],0,sizeof(int)*n);
    }
    brute_force(a,b,c,m,n,p);

    
}
