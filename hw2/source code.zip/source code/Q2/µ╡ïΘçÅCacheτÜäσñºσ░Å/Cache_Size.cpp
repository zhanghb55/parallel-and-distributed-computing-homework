#include <iostream>
#include <random>
#include <ctime>
#include <algorithm>
#include <fstream>
#include <unistd.h>
#include <sys/time.h>

#define KB(x) ((unsigned int)(x) << 10)

using namespace std;

int main()
{
    ofstream out;
    out.open("res.txt");
    // 需要测试的数组的大小
    vector<unsigned int> sizes_KB;
    for (int i = 1; i < 18; i++)
    {
        sizes_KB.push_back(1 << i);
    }
    random_device rd;
    // 伪随机数算法，计算更快，占用内存更少
    mt19937 gen(rd());
    
    volatile register int temp;
    for (size_t size : sizes_KB)
    {
        // 离散均匀分布类
        uniform_int_distribution<> dis(0, KB(size) - 1);
        // 创建连续内存块
        vector<char> memory(KB(size));
        // 在内存中填入内容
        fill(memory.begin(), memory.end(), 1);
        
        
        // 在内存上进行大量的随机访问并计时
        clock_t begin = clock();
        // 1<<25：将1左移25位，进行大量随机访问
        for (int i = 0; i < (1 << 25); i++)
        {
            temp = memory[dis(gen)];
        }
        clock_t end = clock();
        
        // 输出
        double elapsed_secs = double(end - begin) / CLOCKS_PER_SEC;
        cout << "Size of space accessed by the program: " <<size << " KB, it takes " << elapsed_secs << "secs" << endl;
        out << size << " " << elapsed_secs << endl;
    }
    out.close();
}
