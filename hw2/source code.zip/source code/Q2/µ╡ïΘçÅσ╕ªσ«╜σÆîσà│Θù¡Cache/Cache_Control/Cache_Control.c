#include <linux/init.h>
#include <linux/module.h>
MODULE_LICENSE("Dual BSD/GPL");
static int disable(void)
{
        printk(KERN_ALERT "CD = 1,NW = 0,turn to No-fill Cache Mode to disable L1 Cache.\n");
        __asm__("push   %rax\n\t"
                "mov    %cr0,%rax;\n\t"
                "or     $(1 << 30),%rax;\n\t"
		"and     $~(1 << 29),%rax;\n\t"
                "mov    %rax,%cr0;\n\t"
                "wbinvd\n\t"
                "pop    %rax"
);
        return 0;
}
static void enable(void)
{
        printk(KERN_ALERT "CD = 0, NW = 0, turn to Normal Cache Mode to enable L1 Cache.\n");
        __asm__("push   %rax\n\t"
                "mov    %cr0,%rax;\n\t"
                "and     $~(1 << 30),%rax;\n\t"
		"and     $~(1 << 29),%rax;\n\t"
                "mov    %rax,%cr0;\n\t"
                "wbinvd\n\t"
                "pop    %rax"
);
}
module_init(disable);
module_exit(enable);
