#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/time.h>
#include <math.h>
 
 
#define N 33684000

extern void cache();
double get_time() {
    struct timeval tp;
    struct timezone tzp;
    gettimeofday(&tp, &tzp);
    return ((double)tp.tv_sec + (double)tp.tv_usec * 1.e-6 );
}
 
int main(int argc, char *argv[]) {
    cache();
    int i, j;
    double t1, t2;
    double w_cost = 0;
    double r_cost = 0;
    volatile register double temp;
    static double mem[N];
 
    printf("Test writing %ld MB data for 10 times...\n", N * sizeof(double) / 1024 / 1024);
    for (j = 0; j < 10; j++) {
        t1 = get_time();
        for (i = 0; i < N; i++) {
            mem[i] = N;
        }
        t2 = get_time();
 
        if (j != 0) {
            w_cost += t2 - t1;
        }
    }
 
    printf("\n\tWrite: cost %lf seconds, bandwidth %lf MBps\n\n",
            w_cost, 9.0 * N * sizeof(double) * 1.0E-06 / w_cost);
 
    printf("Test reading %ld MB data for 10 times...\n", N * sizeof(double) / 1024 / 1024);
    for (j = 0; j < 10; j++) {
        t1 = get_time();
        for (i = 0; i < N; i++) {
            temp = mem[i];
        }
        t2 = get_time();
        if (j != 0) {
            r_cost += t2 - t1;
        }
    }
    printf("\n\tRead:  cost %lf seconds, bandwidth %lf MBps\n\n",
            r_cost, 9.0 * N * sizeof(double) * 1.0E-06 / r_cost);
 
    return 0;
}
