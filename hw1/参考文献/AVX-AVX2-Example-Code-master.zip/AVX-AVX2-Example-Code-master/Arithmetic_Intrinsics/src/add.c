/**
 * Author:  TripleZ<me@triplez.cn>
 * Date:    2018-08-17
 */

#include <immintrin.h>
#include <stdio.h>
#include  <sys/time.h>
#define N 1000000

int main(int argc, char const *argv[]) {
    __m256i vec1[N/8 + 1];
    __m256i vec2[N/8 + 1];
    __m256i res[N/8 + 1];
    struct timeval begin1,end1,begin2,end2;
    gettimeofday(&begin1,NULL);
    for(int i = 0;i < N / 8;i++){
        for(int j = 0;j < 8;j++){
            res[i][j] = vec1[i][j] + vec2[i][j];
        }
    }
    gettimeofday(&end1,NULL);
    printf("time1:%ldμs\n",1000000*end1.tv_sec + end1.tv_usec - 1000000*begin1.tv_sec - begin1.tv_usec);
    gettimeofday(&begin2,NULL);
    for(int i = 0;i < N/8;i++){
        res[i] = _mm256_add_epi32(vec1[i],vec2[i]);
    }
    gettimeofday(&end2,NULL);
    printf("time2:%ldμs\n",1000000*end2.tv_sec + end2.tv_usec - 1000000*begin2.tv_sec - begin2.tv_usec);
    return 0;
}
